﻿using Microsoft.AspNetCore.Mvc;
using MovieApp.Entity;
using MovieBusiness.Services;

namespace MovieAPI.Controllers
{
    public class MovieController : Controller
    {
        MovieService _movieService;

        public MovieController(MovieService movieService)
        {
            _movieService = movieService;
        }

        [HttpGet("GetMovies")]
        public IActionResult GetMovies()
        {
            return Ok(_movieService.GetMovies());
        }

        [HttpPost("RegisterMovie")]
        public IActionResult Register(MovieModel movieModel)
        {
            return Ok(_movieService.Register(movieModel));
        }
    }
}
