﻿using Microsoft.AspNetCore.Mvc;
using MovieApp.Entity;
using MovieBusiness.Services;

namespace MovieAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpPost("Login")]
        public IActionResult Login(UserModel user)
        {
            if (user != null)
                return Ok("Login success!!");
            else
                return NotFound();
        }
        [HttpGet("SelectedUsers")]
        public IActionResult SelectedUsers()
        {
            return Ok(_userService.SelectedUsers());
        }

        [HttpPost("Register")]
        public IActionResult Register(UserModel userModel)
        {
            return Ok(_userService.Register(userModel));
        }

        [HttpPut("Update")]
        public IActionResult Update(UserModel userModel, int id)
        {
            return Ok(_userService.Update(userModel, id));
        }




    }
}
