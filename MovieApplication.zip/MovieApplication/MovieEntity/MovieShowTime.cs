﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieApp.Entity
{
    public class MovieShowTime
    {
        public int ShowId { get; set; }
        [ForeignKey("movieModel")]
        public int MovieId { get; set; }
        public MovieModel movieModel { get; set; }
        [ForeignKey("theatreModel")]
        public int TheatreId { get; set; }
        public TheatreModel TheatreModel { get; set; }
        public string ShowTime { get; set; }
        public string Date { get; set; }

    }
}
