﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieApp.Entity
{
    public class MovieModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int MovieId { get; set; }
        public string MovieName { get; set; }
        public string Genre { get; set; }
        public int Rating { get; set; }

        //Constructor
        public MovieModel(int movieId, string movieName, string genre, int rating)
        {
            MovieId = movieId;
            MovieName = movieName;
            Genre = genre;
            Rating = rating;
        }
    }
}
