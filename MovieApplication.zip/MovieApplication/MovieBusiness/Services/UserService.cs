﻿using MovieApp.Entity;
using MovieData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBusiness.Services
{
    public class UserService
    {

        IUser _iUser;

        public UserService(IUser iUser)
        {
            _iUser = iUser;
        }

        public string Register(UserModel userModel)
        {
            return _iUser.Register(userModel);
        }

        public object SelectedUsers()
        {
            return _iUser.SelectedUsers();

        }

        public string Login(UserModel userModel)
        {
            return _iUser.Login(userModel);
        }

        public string Logout()
        {
            return _iUser.Logout();
        }

        public string Delete(int id)
        {
            return _iUser.Delete(id);
        }

        public string Update(UserModel user, int id)
        {
            return _iUser.Update(user, id);

        }
    }
}
