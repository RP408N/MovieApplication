﻿using MovieApp.Entity;
using MovieData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieBusiness.Services
{
    public class MovieService
    {
        IMovie _iMovie;

        public MovieService(IMovie iMovie)
        {
            _iMovie = iMovie;
        }

        public string Register(MovieModel movieModel)
        {
            return _iMovie.Register(movieModel);
        }
        public string Delete(int id)
        {
            return _iMovie.Delete(id);
        }
        public object GetMovies()
        {
            return _iMovie.GetMovies();
        }

        public string Update(MovieModel movie, int id)
        {
            return _iMovie.Update(movie, id);
        }
    }
}
