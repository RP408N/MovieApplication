﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.Repositories
{
    public interface IMovieShowTime
    {
        string InsertMovieShowTime(MovieShowTime movieShowTime);
        
        List<MovieApp.Entity.MovieShowTime> ShowMovieShowTime();
    }
}
