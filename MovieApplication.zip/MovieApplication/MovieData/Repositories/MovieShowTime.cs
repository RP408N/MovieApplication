﻿using MovieData.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.Repositories
{
    MovieDbContext _movieDbContext;
    public class MovieShowTime
    {
        public MovieShowTime(MovieDbContext movieDbContext)
        {
            movieDbContext = movieDbContext;    
        }


    }
}
