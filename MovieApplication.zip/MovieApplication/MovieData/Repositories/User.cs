﻿using MovieData.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using MovieApp.Entity;

namespace MovieData.Repositories
{
    public class User: IUser
    {
        MovieDbContext _movieDbContext;

        //Constructor
        public User(MovieDbContext movieDbContext)
        {
            _movieDbContext = movieDbContext;
        }

        //Step1 Register User
        public string Register(UserModel userModel)
        {
            string msg = "";
            _movieDbContext.userModel.Add(userModel);
            _movieDbContext.SaveChanges();
            msg = "Inserted Successfully";
            return msg;
        }

        //Step2 Delete User
        public string Delete(int id)
        {
            string msg = "";
            var toDelete = _movieDbContext.userModel.Find(id);
            if(toDelete != null)
            {
                msg = "Id Not Found in Database";
            }
            _movieDbContext.userModel.Remove(toDelete);
            _movieDbContext.SaveChanges();
            return msg = "Deleted Successfully";
        }

        //Step 3 Select Users from List
        public object SelectedUsers()
        {
             List<UserModel> userList = _movieDbContext.userModel.ToList();
             return userList;
            //return _movieDbContext.userModel.ToList(); 
        }

        //Step4 : Update the Model

        public string Update(UserModel userModel, int id)
        {
            string msg = "";
            var toUpdate = _movieDbContext.userModel.Find(id);
            if(toUpdate == null)
            {
                msg = "Id not Found in Database, Can't Update";
            }
            _movieDbContext.Update(toUpdate);
            _movieDbContext.SaveChanges();
            msg = "Details Updated Successfully";
            return msg;
        }

        public string Login(UserModel userModel)
        {
            throw new NotImplementedException();
        }

        public string Logout()
        {
            throw new NotImplementedException();
        }

        
    }


}
