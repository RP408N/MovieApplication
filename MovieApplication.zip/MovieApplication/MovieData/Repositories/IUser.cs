﻿using MovieApp.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.Repositories
{
    public interface IUser
    {

       //These are the actions/activities which ARE TO BE PERFORMED WITH user details
        string Register(UserModel userModel);
        string Login(UserModel userModel);
        string Logout();
        string Delete( int id);
        string Update(UserModel user, int id);
        object SelectedUsers();
    }
}
