﻿using MovieApp.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.Repositories
{
    public interface IMovie
    {
        string Register(MovieModel movieModel);
        string Delete(int id);
        object GetMovies();
        string Update(MovieModel movie, int id);
    }
}
