﻿using MovieApp.Entity;
using MovieData.DbConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.Repositories
{
    public class Movie: IMovie
    {
        MovieDbContext _movieDbContext;

        //COnstructor
        public Movie(MovieDbContext movieDbContext)
        {
            _movieDbContext = movieDbContext;
        }

        //Deletion of Movie
        public string Delete(int id)
        {
            string msg = "";
            var toDelete = _movieDbContext.movieModel.Find(id);
            if (toDelete != null)
            {
                msg = "Movie Not Present, Can't Delete";
            }
            _movieDbContext.movieModel.Remove(toDelete);
            _movieDbContext.SaveChanges();
            return msg = "Movie Deleted Successfully";
        }

        public object GetMovies()
        {
            return _movieDbContext.movieModel.ToList();
        }

        public string Register(MovieModel movieModel)
        {
            string msg = "";
            _movieDbContext.movieModel.Add(movieModel);
            _movieDbContext.SaveChanges();
            return msg = "Movie Registered Successfully";
        }

        public string Update(MovieModel movie, int id)
        {
            string msg = "";
            var toUpdate=_movieDbContext.movieModel.Find(id);
            _movieDbContext.movieModel.Update(toUpdate);
            _movieDbContext.SaveChanges();
            return msg = "Movie Updated Successfully";
        }
    }
}
