﻿using Microsoft.EntityFrameworkCore;
using MovieApp.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieData.DbConnection
{
    public class MovieDbContext:DbContext
    {

        public MovieDbContext(DbContextOptions<MovieDbContext> options): base(options)
        {

        }

        //DbSet is given to create table
        public DbSet<UserModel> userModel { get; set; }

        public DbSet<MovieModel> movieModel { get; set; }


    }
}
